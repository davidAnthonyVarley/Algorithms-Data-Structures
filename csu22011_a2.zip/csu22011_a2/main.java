package csu22011_a2;

public class main {

	public static void main(String[] args) {
		DoublyLinkedList<Integer> testDLL = new DoublyLinkedList<Integer>();
//		testDLL.insertBefore(0,1);
//		System.out.println( testDLL.listLength);
//        testDLL.insertBefore(1,2);
//		System.out.println( testDLL.listLength);
//        testDLL.insertBefore(2,3);
//        System.out.println( testDLL.listLength);
//        
        //DoublyLinkedListTest testdll = new DoublyLinkedListTest();
        
        //testdll.testInsertBefore();
//        dll.insertBefore(1,2);
//        System.out.println( dll.listLength);
//        
//        dll.insertBefore(2,3);
//        System.out.println( dll.listLength);
        
        System.out.println( testDLL.isEmpty());
    	testDLL.insertBefore(1, 3);
        testDLL.insertBefore(2, 2);
        testDLL.insertBefore(0, 1);
        System.out.println( testDLL.isEmpty());
        
        

	}

}
